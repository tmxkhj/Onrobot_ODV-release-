"""Regression checks for a fixed robot wrist and suspended product assembly."""
import itertools
import math
import unittest

from graphics import ANCHOR, HEX_TOP, draw_model, mesh, project_point, transform_point


REST = (0.0,) * 6
EXTREME_POSES = tuple(itertools.product(*[(-v, v) for v in
    (.9, .9, .9, math.radians(35), math.radians(35), math.radians(35))]))
POSES = (REST, (.6, -.4, .3, .15, -.25, .2)) + EXTREME_POSES
SCENE_POINTS = {kind: tuple(dict.fromkeys(point for face, _ in mesh(kind) for point in face))
                for kind in ('mount', 'link', 'assembly')}


class RecordingSurface:
    """Record the renderer's output without creating a window."""
    def __init__(self):
        self.polygons = []
        self.texts = []

    def create_polygon(self, *coords, **options):
        self.polygons.append(tuple(zip(coords[::2], coords[1::2])))

    def create_text(self, *coords, **options):
        self.texts.append((coords, options))

    def create_line(self, *coords, **options):
        pass

    def create_oval(self, *coords, **options):
        pass


class FixedMountTests(unittest.TestCase):
    def assertPointAlmostEqual(self, actual, expected):
        for a, e in zip(actual, expected):
            self.assertAlmostEqual(a, e, places=10)

    def test_wrist_is_stationary_for_all_force_and_torque_inputs(self):
        bounds = (73, 29, 430, 385)
        for pose in POSES:
            for point in SCENE_POINTS['mount']:
                world = transform_point(point, pose, 'mount')
                self.assertEqual(world, point)
                self.assertEqual(project_point(world, bounds), project_point(point, bounds))

    def test_zero_input_returns_original_assembly_geometry(self):
        for point in SCENE_POINTS['assembly']:
            self.assertPointAlmostEqual(transform_point(point, REST), point)

    def test_hex_and_gripper_remain_one_rigid_assembly(self):
        # Points span the HEX flange, housing, connector and three fingertips.
        points = (HEX_TOP, (.59, 0, 1.63), (1.1, 0, 1.56),
                  (1.075, 0, -1.7), (-.5375, .931, -1.7), (-.5375, -.931, -1.7))
        for pose in POSES:
            transformed = [transform_point(p, pose) for p in points]
            for i, j in itertools.combinations(range(len(points)), 2):
                self.assertAlmostEqual(math.dist(points[i], points[j]),
                                       math.dist(transformed[i], transformed[j]), places=10)

    def test_connector_stays_attached_to_wrist_and_hex(self):
        for pose in POSES:
            top = transform_point(ANCHOR, pose, 'link')
            bottom = transform_point(HEX_TOP, pose, 'link')
            self.assertPointAlmostEqual(top, ANCHOR)
            self.assertPointAlmostEqual(bottom, transform_point(HEX_TOP, pose, 'assembly'))
            self.assertGreater(math.dist(top, bottom), .20)

    def test_force_sways_lower_product_around_fixed_upper_anchor(self):
        lower = (0, 0, -1.7)
        for axis in (0, 1):
            for sign in (-1, 1):
                pose = [0.] * 6
                pose[axis] = sign * .6
                moved = transform_point(lower, pose)
                self.assertGreater(sign * moved[axis], 0)
                # Swing raises a hanging point along its circular arc.
                self.assertGreater(moved[2], lower[2])
                self.assertAlmostEqual(math.dist(moved, ANCHOR), math.dist(lower, ANCHOR))
        for sign in (-1, 1):
            moved = transform_point(lower, (0, 0, sign * .6, 0, 0, 0))
            self.assertGreater(sign * (moved[2] - lower[2]), 0)
            self.assertEqual(moved[:2], lower[:2])

    def test_fixed_camera_contains_all_extreme_pose_combinations(self):
        # Includes the small-window, standard and full-HD presentation stages.
        for bounds in ((11, 23, 396, 258), (19, 31, 532, 434), (29, 47, 700, 550)):
            left, top, width, height = bounds
            for pose in POSES:
                for component, points in SCENE_POINTS.items():
                    for point in points:
                        x, y, _ = project_point(transform_point(point, pose, component), bounds)
                        self.assertTrue(left <= x <= left + width and top <= y <= top + height,
                                        (bounds, pose, component, (x, y)))

    def test_renderer_uses_fixed_projection_without_recentering(self):
        bounds = (13, 31, 420, 310)
        label_positions = []
        for pose in (REST, POSES[1], EXTREME_POSES[0], EXTREME_POSES[-1]):
            expected = {(round(x, 7), round(y, 7))
                        for component, points in [('assembly', SCENE_POINTS['assembly'])]
                        for point in points
                        for x, y, _ in [project_point(transform_point(point, pose, component), bounds)]}
            surface = RecordingSurface()
            draw_model(surface, bounds, pose, True)
            self.assertGreater(len(surface.polygons), 100)
            for polygon in surface.polygons:
                for x, y in polygon:
                    self.assertIn((round(x, 7), round(y, 7)), expected)
            self.assertEqual({options.get('text') for _,options in surface.texts}, {'X','Y','Z'})
            label_positions.append(tuple(coords for coords,options in surface.texts))
        self.assertTrue(all(position == label_positions[0] for position in label_positions))


if __name__ == '__main__':
    unittest.main(verbosity=2)
