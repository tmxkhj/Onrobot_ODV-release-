"""Fixed wrist and camera, with a suspended HEX QC + 3FG25 assembly."""
import math

AXES = ('Fx','Fy','Fz','Tx','Ty','Tz')
COLORS = ('#14815c','#1685b8','#b8751c')
ANCHOR = (0.0, 0.0, 2.42)
HEX_TOP = (0.0, 0.0, 1.975)
MAX_SWING = math.radians(32)
VIEW = (-3.8, 3.8, -3.6, 2.45)


def rotation(p, angles):
    x,y,z = p
    a,b,c = angles
    y,z = y*math.cos(a)-z*math.sin(a), y*math.sin(a)+z*math.cos(a)
    x,z = x*math.cos(b)+z*math.sin(b), -x*math.sin(b)+z*math.cos(b)
    x,y = x*math.cos(c)-y*math.sin(c), x*math.sin(c)+y*math.cos(c)
    return x,y,z


def shade(color, factor):
    return '#'+''.join(f'{max(0,min(255,round(int(color[i:i+2],16)*factor))):02x}' for i in (1,3,5))


def mesh(kind='assembly'):
    """Photo-based proportions, not CAD. HEX datasheet p1/7; 3FG25 p1/3."""
    faces = []
    def loft(rings, color, n=48, center=(0,0,0), orient=(0,0,0)):
        loops=[]
        for z,r,lobe in rings:
            loop=[]
            for i in range(n):
                a=i*math.tau/n
                radius=r+lobe*math.cos(3*a)
                p=rotation((radius*math.cos(a),radius*math.sin(a),z),orient)
                loop.append(tuple(p[k]+center[k] for k in range(3)))
            loops.append(loop)
        faces.append((list(reversed(loops[0])),color))
        faces.append((loops[-1],color))
        for lo,hi in zip(loops,loops[1:]):
            for i in range(n):
                j=(i+1)%n
                faces.append(([lo[i],lo[j],hi[j],hi[i]],color))
    def cylinder(radius,bottom,top,color,n=32,center=(0,0,0),orient=(0,0,0)):
        loft([(bottom,radius,0),(top,radius,0)],color,n,center,orient)
    def box(cx,cy,cz,dx,dy,dz,color,angle=0):
        pts=[rotation((cx+x*dx/2,cy+y*dy/2,cz+z*dz/2),(0,0,angle)) for x,y,z in
             [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
        for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:
            faces.append(([pts[i] for i in ids],color))
    if kind == 'mount':
        # Neutral robot wrist / J6 flange. It is a fixed scene reference, not
        # another sensor and not a model of a particular robot manufacturer.
        box(0,0,3.34,2.0,1.25,.16,'#e2e8ec')
        cylinder(.60,2.69,3.29,'#c6cfd5',48)
        cylinder(.62,3.15,3.25,'#e0e5e8',48)
        cylinder(.61,2.61,2.70,'#65747f',48)
        cylinder(.75,2.43,2.61,'#aab7c0',48)
        cylinder(.75,2.40,2.44,'#d8e0e5',48)
        for a in (.35,1.92,3.49,5.06):
            center=(.68*math.cos(a),.68*math.sin(a),0)
            cylinder(.043,2.611,2.617,'#4d5f6b',12,center)
        return faces
    if kind == 'link':
        # Short visual connector keeps the fixed wrist and moving HEX joined
        # while the amplified axial input extends or compresses their spacing.
        cylinder(.12,HEX_TOP[2],ANCHOR[2],'#778b98',24)
        cylinder(.18,HEX_TOP[2],HEX_TOP[2]+.045,'#bcc8d0',24)
        return faces
    # Three rounded actuator lobes blending into a slender cylindrical neck.
    loft([(-.65,.89,.13),(-.57,.90,.13),(-.45,.88,.17),(-.33,.85,.20),
          (-.22,.81,.21),(-.12,.75,.20),(-.03,.68,.16),(.06,.61,.09),
          (.15,.56,.035),(.26,.535,.005),(.38,.53,0),(.98,.53,0)],'#c3c9cc',60)
    loft([(-.69,.88,.13),(-.65,.90,.13)],'#707b82',60)
    loft([(-.64,.91,.13),(-.59,.91,.13)],'#dae0e3',60)
    # Blue Quick Changer collar shown in the product photograph.
    cylinder(.535,.98,1.16,'#278fc5',48)
    cylinder(.54,1.145,1.18,'#89c9e4',48)
    box(.46,.18,1.07,.16,.22,.10,'#237da9',.5)
    # HEX: silver flanges and black sensor band; no invented green ring.
    cylinder(.59,1.18,1.39,'#d2d8db',48)
    cylinder(.565,1.39,1.63,'#242d32',48)
    cylinder(.59,1.63,1.88,'#c9d0d4',48)
    cylinder(.60,1.87,1.94,'#e4e9eb',48)
    cylinder(.29,1.94,1.975,'#9baab3',32)
    for a in (.3,1.87,3.44,5.01):
        center=(.43*math.cos(a),.43*math.sin(a),0)
        cylinder(.064,1.941,1.947,'#627079',16,center)
        cylinder(.037,1.948,1.952,'#18242b',12,center)
    # Connector block extends sideways from HEX, with threaded M12 barrel.
    box(.71,0,1.55,.30,.38,.39,'#9daab2')
    cylinder(.125,0,.23,'#46525a',24,(.86,0,1.56),(0,math.pi/2,0))
    for x in (.90,.95,1.00,1.05):
        cylinder(.132,0,.018,'#a1b0ba',24,(x,0,1.56),(0,math.pi/2,0))
    cylinder(.105,0,.012,'#111c23',20,(1.095,0,1.56),(0,math.pi/2,0))
    # Short bent metal fingers, each carried by a circular rotating platform.
    # Cross section is extruded tangentially, rather than a rectangular claw.
    section=[(.60,-.76),(.89,-.77),(1.12,-.98),(1.14,-1.24),
             (1.01,-1.24),(1.00,-1.05),(.82,-.90),(.60,-.88)]
    for a in (0,math.tau/3,math.tau*2/3):
        center=(.66*math.cos(a),.66*math.sin(a),0)
        cylinder(.28,-.77,-.70,'#9ba6ac',32,center)
        sides=[[rotation((x,y,z),(0,0,a)) for x,z in section] for y in (-.09,.09)]
        faces.append((sides[0],'#d6dcdf'));faces.append((list(reversed(sides[1])),'#d6dcdf'))
        for i in range(len(section)):
            j=(i+1)%len(section)
            faces.append(([sides[0][i],sides[1][i],sides[1][j],sides[0][j]],'#c3ccd1'))
        tip=(1.075*math.cos(a),1.075*math.sin(a),0)
        cylinder(.093,-1.31,-1.10,'#d7e0e5',24,tip)
        cylinder(.137,-1.70,-1.28,'#252c30',32,tip)
        cylinder(.141,-1.32,-1.28,'#39434a',32,tip)
        # Subtle circumferential texture makes the black grip sleeves legible.
        for z in (-1.39,-1.48,-1.57,-1.66):
            cylinder(.139,z,z+.012,'#364047',24,tip)
    return faces


MODEL = mesh()


def _prepare_model(model=MODEL):
    """Compile shared vertices, unit normals, centroids and material palettes.

    The model is a rigid assembly, so all this geometry is constant. In
    particular, a face normal can be shaded with an inverse-rotated light;
    it does not need to be rebuilt from transformed points on every frame.
    """
    vertices=[]
    vertex_ids={}
    faces=[]
    palettes={}
    for points,color in model:
        indices=[]
        for point in points:
            index=vertex_ids.get(point)
            if index is None:
                index=len(vertices)
                vertices.append(point)
                vertex_ids[point]=index
            indices.append(index)
        x,y,z=points[0]
        ux,uy,uz=points[1][0]-x,points[1][1]-y,points[1][2]-z
        vx,vy,vz=points[2][0]-x,points[2][1]-y,points[2][2]-z
        nx,ny,nz=uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx
        length=math.sqrt(nx*nx+ny*ny+nz*nz) or 1.0
        normal=(nx/length,ny/length,nz/length)
        count=len(points)
        center=tuple(sum(p[i] for p in points)/count for i in range(3))
        if color not in palettes:
            rgb=tuple(int(color[i:i+2],16) for i in (1,3,5))
            # 1/1024 intensity steps are below one RGB level. Cache their
            # hexadecimal strings once, avoiding per-face parsing/formatting.
            palettes[color]=tuple('#'+''.join(f'{min(255,round(c*i/1024)):02x}' for c in rgb)
                                  for i in range(1409))
        double_sided = color in ('#d6dcdf', '#c3ccd1')
        faces.append((tuple(indices),normal,center,palettes[color],double_sided))
    return tuple(vertices),tuple(faces)


_VERTICES,_FACES = _prepare_model()
# Keep the upper anchor in the motion math only. The exhibition view contains
# the actual HEX QC + 3FG25, with no robot wrist or illustrative connector.
_SCENE = (('assembly', _VERTICES, _FACES),)


def hanging_motion(displacement):
    """Map force to a swing about the wrist, then add measured torque tilt."""
    tx,ty,tz,a,b,c=displacement
    a=max(-MAX_SWING,min(MAX_SWING,a+math.atan2(ty,3.6)))
    b=max(-MAX_SWING,min(MAX_SWING,b-math.atan2(tx,3.6)))
    c=max(-math.radians(35),min(math.radians(35),c))
    axial=max(-.22,min(.22,tz*.32))
    return (a,b,c),axial


def _link_weight(z):
    return max(0.0,min(1.0,(ANCHOR[2]-z)/(ANCHOR[2]-HEX_TOP[2])))


def transform_point(point, displacement, component='assembly'):
    """World transform, exposed for anchor/connection regression tests."""
    if component == 'mount':
        return tuple(point)
    angles,axial=hanging_motion(displacement)
    x,y,z=point
    z=z-ANCHOR[2]+axial*(_link_weight(z) if component=='link' else 1.0)
    x,y,z=rotation((x,y,z),angles)
    return x,y,z+ANCHOR[2]


def camera(bounds):
    """A fixed orthographic view. Only a window resize changes its scale."""
    left,top,width,height=bounds
    xmin,xmax,ymin,ymax=VIEW
    scale=max(.01,min((width-24)/(xmax-xmin),(height-24)/(ymax-ymin)))
    cx=left+width/2-scale*(xmin+xmax)/2
    cy=top+height/2-scale*(ymin+ymax)/2
    return cx,cy,scale


def project_point(point,bounds):
    cx,cy,scale=camera(bounds)
    x,y,z=point
    return cx+scale*(.85*x-.53*y),cy+scale*(.17*x+.27*y-.95*z),.50*x+.80*y+.32*z


def draw_model(canvas, bounds, displacement, active):
    left,top,width,height=bounds
    cx,cy,scale=camera(bounds)
    angles,axial=hanging_motion(displacement)
    a,b,c=angles
    sa,ca,sb,cb,sc,cc=math.sin(a),math.cos(a),math.sin(b),math.cos(b),math.sin(c),math.cos(c)
    rotation_matrix=(cc*cb,cc*sb*sa-sc*ca,cc*sb*ca+sc*sa,
                     sc*cb,sc*sb*sa+cc*ca,sc*sb*ca-cc*sa,
                     -sb,cb*sa,cb*ca)
    rendered=[]
    for component,vertices,faces in _SCENE:
        fixed=component=='mount'
        r00,r01,r02,r10,r11,r12,r20,r21,r22=(1,0,0,0,1,0,0,0,1) if fixed else rotation_matrix
        px0,px1,px2=.85*r00-.53*r10,.85*r01-.53*r11,.85*r02-.53*r12
        py0,py1,py2=.17*r00+.27*r10-.95*r20,.17*r01+.27*r11-.95*r21,.17*r02+.27*r12-.95*r22
        pd0,pd1,pd2=.50*r00+.80*r10+.32*r20,.50*r01+.80*r11+.32*r21,.50*r02+.80*r12+.32*r22
        origin_y=cy if fixed else cy-scale*.95*ANCHOR[2]
        origin_depth=0 if fixed else .32*ANCHOR[2]
        if fixed:
            adjusted=vertices
        elif component=='link':
            adjusted=[(x,y,z-ANCHOR[2]+axial*_link_weight(z)) for x,y,z in vertices]
        else:
            adjusted=[(x,y,z-ANCHOR[2]+axial) for x,y,z in vertices]
        projected=[(cx+scale*(px0*x+px1*y+px2*z),
                    origin_y+scale*(py0*x+py1*y+py2*z)) for x,y,z in adjusted]
        lx,ly,lz=-.45*r00+.65*r10+.61*r20,-.45*r01+.65*r11+.61*r21,-.45*r02+.65*r12+.61*r22
        sx,sy,sz=.03*r00+.84*r10+.54*r20,.03*r01+.84*r11+.54*r21,.03*r02+.84*r12+.54*r22
        factor=1.0 if active or fixed else .98
        for indices,(nx,ny,nz),(x,y,z),palette,double_sided in faces:
            if not double_sided and nx*pd0+ny*pd1+nz*pd2<=0:
                continue
            light=nx*lx+ny*ly+nz*lz
            specular=max(0,nx*sx+ny*sy+nz*sz)**20
            intensity=round((.70+.31*max(0,light)+.25*specular)*factor*1024)
            if not fixed:
                z=z-ANCHOR[2]+axial*(_link_weight(z) if component=='link' else 1.0)
            depth=origin_depth+pd0*x+pd1*y+pd2*z
            coords=[value for index in indices for value in projected[index]]
            rendered.append((depth,coords,palette[intensity]))
    # All objects share one stationary camera and light. No force-dependent
    # pan, zoom, fit, or recentering is applied to any projected coordinate.
    for _,coords,color in sorted(rendered,key=lambda face:face[0]):
        canvas.create_polygon(*coords,fill=color,outline=color)
    ox,oy=left+47,top+height-42
    for dx,dy,label,col in [(29,11,'X',COLORS[0]),(-19,20,'Y',COLORS[1]),(0,-30,'Z',COLORS[2])]:
        canvas.create_line(ox,oy,ox+dx,oy+dy,fill=col,width=2,arrow='last',arrowshape=(5,6,2))
        canvas.create_text(ox+dx*1.36,oy+dy*1.36,text=label,fill=col,font=('Segoe UI',9,'bold'))
    canvas.create_oval(ox-2,oy-2,ox+2,oy+2,fill='#607786',outline='')


def move(current, values, settings, dt):
    out=[]
    for i,(v,cfg) in enumerate(zip(values,settings)):
        amount=math.copysign(max(0,abs(v)-cfg['deadband']),v)
        limit=cfg['limit']
        target=max(-limit,min(limit,amount*cfg['gain']*(-1 if cfg['invert'] else 1)))
        if i>=3: target=math.radians(target)
        alpha=1-math.exp(-dt/max(.001,cfg['smoothing']))
        out.append(current[i]+alpha*(target-current[i]))
    return out
