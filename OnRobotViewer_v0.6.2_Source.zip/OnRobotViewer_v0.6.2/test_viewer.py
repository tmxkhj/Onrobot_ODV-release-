import copy
import socket
import socketserver
import struct
import tempfile
import threading
import time
import unittest
from pathlib import Path
from protocol import Client, ModbusError, decode, signed16
from engine import Engine
from graphics import move
from viewer import DEFAULT, validate
from plots import nice_limit, trace_segments


class Handler(socketserver.BaseRequestHandler):
    def exact(self,n):
        b=b''
        while len(b)<n:
            try:x=self.request.recv(n-len(b))
            except ConnectionError:return None
            if not x:return None
            b+=x
        return b

    def handle(self):
        while True:
            h=self.exact(7)
            if h is None:return
            tid,proto,n,unit=struct.unpack('>HHHB',h)
            p=self.exact(n-1)
            if p is None:return
            fc,addr,count=struct.unpack('>BHH',p)
            self.server.requests.append((unit,fc,addr,count))
            mode=self.server.mode
            if mode=='drop':return
            if mode=='timeout':time.sleep(.2);return
            if fc==6:
                reply=p
                if mode=='echo':reply=struct.pack('>BHH',6,0,0)
            elif mode=='exception':reply=bytes((0x83,2))
            else:
                values=[]
                for a in range(addr,addr+count):
                    values.append({1536:0x22,259:65535,260:32768,261:32767,262:65535,263:100,264:0}.get(a,0))
                reply=bytes((3,len(values)*2))+struct.pack('>'+'H'*count,*values)
                if mode=='bytecount':reply=bytes((3,0))+reply[2:]
            header=struct.pack('>HHHB',tid+(mode=='tid'),1 if mode=='protocol' else 0,len(reply)+1,unit+(mode=='unit'))
            if mode=='length':header=struct.pack('>HHHB',tid,0,65535,unit)
            try:
                if mode=='fragment':
                    for b in header+reply:self.request.sendall(bytes((b,)))
                else:self.request.sendall(header+reply)
            except OSError:return


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address=True
    daemon_threads=True
    def __init__(self):
        super().__init__(('127.0.0.1',0),Handler)
        self.mode='ok';self.requests=[]
        self.thread=threading.Thread(target=self.serve_forever,daemon=True);self.thread.start()
    def close(self):self.shutdown();self.server_close();self.thread.join()


class ProtocolTests(unittest.TestCase):
    def setUp(self):self.s=Server()
    def tearDown(self):self.s.close()
    def client(self):return Client('127.0.0.1',self.s.server_address[1],65,.1)
    def test_signed_boundaries_and_units(self):
        self.assertEqual([signed16(x) for x in (0,32767,32768,65535)],[0,32767,-32768,-1])
        self.assertEqual(decode((65535,32768,32767,65535,100,0)),(-.1,-3276.8,3276.7,-.01,1.,0.))
    def test_fragmented_read_and_zero_exact_pdu(self):
        self.s.mode='fragment';c=self.client()
        try:self.assertEqual(c.read(259,6)[0],65535);c.zero()
        finally:c.close()
        self.assertEqual(self.s.requests,[(65,3,259,6),(65,6,0,1)])
    def test_bad_frames_rejected(self):
        for mode in ('tid','protocol','unit','length','bytecount','exception','drop','timeout'):
            with self.subTest(mode=mode):
                self.s.mode=mode;c=self.client()
                try:
                    with self.assertRaises((ModbusError,ConnectionError,TimeoutError,OSError)):c.read(259,6)
                finally:c.close()
    def test_wrong_zero_echo_rejected(self):
        self.s.mode='echo';c=self.client()
        try:
            with self.assertRaises(ModbusError):c.zero()
        finally:c.close()
    def test_worker_never_writes_automatically(self):
        e=Engine('127.0.0.1',self.s.server_address[1],'RG2-FT Left');e.start()
        time.sleep(.16);e.stop();e.join(1)
        self.assertFalse(e.is_alive());self.assertGreater(e.count,1)
        self.assertTrue(all(fc==3 for _,fc,_,_ in self.s.requests))
    def test_zero_not_replayed_after_lost_reply(self):
        e=Engine('127.0.0.1',self.s.server_address[1],'RG2-FT Left');e.start()
        deadline=time.perf_counter()+1
        while e.count<2 and time.perf_counter()<deadline:time.sleep(.005)
        self.s.mode='drop';e.command('zero');time.sleep(.12)
        self.s.mode='ok';time.sleep(2.2);e.stop();e.join(1)
        writes=[r for r in self.s.requests if r[1]==6]
        self.assertLessEqual(len(writes),1)
        self.assertGreater(e.count,2)


class PlotTests(unittest.TestCase):
    def test_steps_hold_value_until_actual_sample_and_preserve_peak(self):
        from plots import step_points
        samples = [(0, (0,)*6), (.01, (20,)*6), (.02, (-10,)*6), (.03, (0,)*6)]
        segment = trace_segments(samples, 0, 0, 1, 1, .15)[0]
        self.assertEqual(step_points(segment), [(0,0),(.01,0),(.01,20),(.02,20),(.02,-10),(.03,-10),(.03,0)])
        self.assertEqual(step_points([]), [])

    def test_flat_runs_keep_step_edges_and_gaps(self):
        samples=[(t,(v,)*6) for t,v in [(0,0),(.01,0),(.02,0),(.03,5),(.04,5),(.05,5),(.7,5),(.71,5)]]
        self.assertEqual(trace_segments(samples,0,0,1,100,.15),
                         [[(0,0),(.02,0),(.03,5),(.05,5)],[(.7,5),(.71,5)]])

    def test_extrema_keep_time_order_and_endpoints(self):
        samples=[(i*.01,(v,0,0,0,0,0)) for i,v in enumerate([2,9,-8,1,3])]
        self.assertEqual(trace_segments(samples,0,0,1,1,1),[[(0,2),(.01,9),(.02,-8),(.04,3)]])

    def test_gap_inside_one_pixel_is_not_connected(self):
        samples=[(0,(1,)*6),(.01,(2,)*6),(.8,(3,)*6),(.81,(4,)*6)]
        self.assertEqual(len(trace_segments(samples,0,0,1,1,.15)),2)

    def test_six_axes_remain_independent(self):
        samples=[(0,(1,2,3,.1,.2,.3)),(.01,(2,3,4,.2,.3,.4))]
        for axis in range(6):
            self.assertEqual(trace_segments(samples,axis,0,1,100,.15)[0][0][1],samples[0][1][axis])
        self.assertEqual(nice_limit(17,10),20)
        self.assertEqual(nice_limit(.3,.5),.5)


class DisplayTests(unittest.TestCase):
    def test_settings_nan_and_excessive_motion_rejected(self):
        for key,value in [('gain',float('nan')),('limit',100),('smoothing',0)]:
            cfg=copy.deepcopy(DEFAULT);cfg['axes'][0][key]=value
            with self.assertRaises(ValueError):validate(cfg)
    def test_clamp_deadband_inversion_and_return(self):
        cfg=copy.deepcopy(DEFAULT['axes']);cfg[0]['invert']=True
        pose=[0.]*6
        for _ in range(100):pose=move(pose,[1e9]*6,cfg,.016)
        self.assertLess(pose[0],0);self.assertLessEqual(abs(pose[0]),cfg[0]['limit'])
        self.assertLessEqual(abs(pose[3]),.42)
        for _ in range(200):pose=move(pose,[0.01]*6,cfg,.016)
        self.assertTrue(all(abs(x)<.001 for x in pose))
    def test_sensor_csv_and_stop(self):
        server=Server()
        e=Engine('127.0.0.1',server.server_address[1],'RG2-FT Left')
        try:
            with tempfile.TemporaryDirectory() as d:
                path=Path(d)/'sample.csv';e.start();e.command('record',str(path));time.sleep(.12)
                e.stop();e.join(1)
                self.assertFalse(e.recording)
                lines=path.read_text().splitlines()
                self.assertGreater(len(lines),2)
                self.assertEqual(lines[0],'unix_time,monotonic_time,profile,Fx_N,Fy_N,Fz_N,Tx_Nm,Ty_Nm,Tz_Nm')
        finally:
            e.stop();e.join(1);server.close()


if __name__=='__main__':unittest.main(verbosity=2)
