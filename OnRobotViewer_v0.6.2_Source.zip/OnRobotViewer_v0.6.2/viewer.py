"""Offline OnRobot exhibit viewer with an antialiased product stage."""
import argparse
import collections
import copy
import json
import logging
from logging.handlers import RotatingFileHandler
import math
import os
from pathlib import Path
import queue
import sys
import time
import tkinter as tk
from tkinter import messagebox

from engine import Engine
from demo_engine import DemoEngine
from graphics import AXES, COLORS, draw_model, move
from plots import nice_limit, trace_segments, step_points
from retained_canvas import RetainedCanvas
from product_stage import ProductStage

BASE = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
ASSETS = Path(getattr(sys, '_MEIPASS', BASE)) / 'assets'
DATA = Path(os.environ.get('ONROBOT_VIEWER_DATA', str(BASE / 'user_data')))
BG, WHITE, INK, MUTED = '#f3f6f8', '#ffffff', '#26292b', '#657580'
BLUE, BORDER, SOFT_BLUE = '#499dda', '#dfe4e8', '#e8f3fb'
DEFAULT = {'host': '192.168.1.1', 'port': 502, 'profile': 'HEX QC', 'poll_ms': 10,
           'axes': [{'invert': False, 'gain': .022 if i < 3 else 16.0,
                     'deadband': .3 if i < 3 else .02, 'smoothing': .18,
                     'limit': .65 if i < 3 else 24.0} for i in range(6)]}


def validate(cfg):
    if not isinstance(cfg, dict) or not isinstance(cfg.get('host'), str) or not cfg['host'].strip():
        raise ValueError('Host is required')
    if not isinstance(cfg.get('port'), int) or not 1 <= cfg['port'] <= 65535:
        raise ValueError('Port must be 1..65535')
    if cfg.get('profile') != 'HEX QC':
        raise ValueError('This exhibit uses the HEX QC sensor')
    if not isinstance(cfg.get('poll_ms'), (int, float)) or not math.isfinite(cfg['poll_ms']) or not 2 <= cfg['poll_ms'] <= 1000:
        raise ValueError('PC poll interval must be 2..1000 ms')
    if len(cfg.get('axes', [])) != 6:
        raise ValueError('Exactly six axis settings are required')
    for i, a in enumerate(cfg['axes']):
        for key, lo, hi in [('gain', 0, 1000), ('deadband', 0, 10000), ('smoothing', .001, 10), ('limit', .01, .9 if i < 3 else 35)]:
            v = a.get(key)
            if not isinstance(v, (int, float)) or not math.isfinite(v) or not lo <= v <= hi:
                raise ValueError(f'{AXES[i]} {key}: allowed {lo}..{hi}')
        if not isinstance(a.get('invert'), bool):
            raise ValueError('Invert must be true/false')
    return cfg


class Viewer:
    def __init__(self, root, connect=False, demo=False):
        self.root = root
        root.title('OnRobot | HEX QC + 3FG25')
        root.geometry('1440x900')
        root.minsize(1100, 720)
        root.configure(bg=BG)
        self.cfg = copy.deepcopy(DEFAULT)
        try:
            if (DATA / 'settings.json').exists():
                cfg = json.loads((DATA / 'settings.json').read_text(encoding='utf-8'))
                # Migrate earlier RG test settings to the dedicated exhibition sensor.
                cfg['profile'] = 'HEX QC'
                self.cfg = validate(cfg)
        except Exception as exc:
            logging.exception('Invalid settings; using defaults')
            messagebox.showwarning('Settings', f'Invalid settings; using defaults.\n{exc}')
        self.engine = None
        self.mode = None
        self.history = collections.deque(maxlen=12000)
        self.latest = None
        self.pose = [0.0] * 6
        self.last_frame = time.perf_counter()
        self.frame_times = collections.deque(maxlen=200)
        self.closing = False
        self.pending_start = None
        self.message = ''
        self.widget_states = {}
        self.plot_limits = [10.] * 3 + [.5] * 3
        self.limit_updated = [0.] * 6
        self.build_header()
        self.canvas = RetainedCanvas(root, bg=BG, highlightthickness=0)
        self.canvas.pack(fill='both', expand=True, padx=24, pady=(14, 0))
        self.product_stage = ProductStage(self.canvas)
        bottom = tk.Frame(root, bg=BG)
        bottom.pack(fill='x', padx=28, pady=(8, 12))
        self.footer = tk.Label(bottom, text='', anchor='w', fg=MUTED, bg=BG, font=('Segoe UI', 9))
        self.footer.pack(side='left')
        tk.Label(bottom, text='OnRobot  /  Force & Torque', fg='#7e878e', bg=BG, font=('Segoe UI', 9)).pack(side='right')
        root.bind('<Escape>', lambda _: root.attributes('-fullscreen', False))
        root.bind('<F11>', lambda _: root.attributes('-fullscreen', not root.attributes('-fullscreen')))
        root.protocol('WM_DELETE_WINDOW', self.close)
        if demo:
            self.start('demo')
        elif connect:
            self.start()
        self.frame()

    def build_header(self):
        header = tk.Frame(self.root, bg=WHITE)
        header.pack(fill='x')
        top = tk.Frame(header, bg=WHITE)
        top.pack(fill='x', padx=28, pady=(16, 12))
        self.logo = tk.PhotoImage(data=(ASSETS / 'onrobot_header.png').read_bytes())
        tk.Label(top, image=self.logo, bg=WHITE, bd=0).pack(side='left', padx=(0, 24))
        tk.Frame(top, bg=BORDER, width=1, height=44).pack(side='left', padx=(0, 24))
        title = tk.Frame(top, bg=WHITE)
        title.pack(side='left')
        tk.Label(title, text='HEX QC + 3FG25', bg=WHITE, fg=INK, font=('Segoe UI', 22, 'bold'), anchor='w').pack(anchor='w')
        tk.Label(title, text='Live Force & Torque', bg=WHITE, fg=MUTED, font=('Segoe UI', 11), anchor='w').pack(anchor='w')
        status = tk.Frame(top, bg=WHITE)
        status.pack(side='right')
        self.badge = tk.Label(status, text='  DISCONNECTED  ', font=('Segoe UI', 10, 'bold'), fg=MUTED, bg=BG, padx=12, pady=6)
        self.badge.pack(anchor='e')
        self.source_label = tk.Label(status, text='HEX QC sensor', fg=MUTED, bg=WHITE, font=('Segoe UI', 9))
        self.source_label.pack(anchor='e', pady=(5, 0))
        bar = tk.Frame(header, bg=WHITE)
        bar.pack(fill='x', padx=24, pady=(0, 14))
        self.connect_button = self.button(bar, 'Connect', self.start, accent=True)
        self.disconnect_button = self.button(bar, 'Disconnect', self.disconnect)
        self.zero_button = self.button(bar, 'Zero', self.zero)
        self.demo_button = self.button(bar, 'Demo', self.toggle_demo)
        self.record_button = self.button(bar, 'Record CSV', self.record)
        self.plot_seconds = tk.StringVar(value='2')
        tk.Label(bar, text='Window (s)', bg=WHITE, fg=MUTED, font=('Segoe UI', 9)).pack(side='left', padx=(12, 2))
        tk.OptionMenu(bar, self.plot_seconds, '2', '5', '10').pack(side='left')
        self.button(bar, 'Full Screen', lambda: self.root.attributes('-fullscreen', True), right=True)
        self.button(bar, 'Settings', self.settings, right=True)
        tk.Frame(header, height=1, bg=BORDER).pack(fill='x')

    def button(self, parent, text, callback, accent=False, right=False):
        b = tk.Button(parent, text=text, command=callback, font=('Segoe UI', 10, 'bold' if accent else 'normal'),
                      bg=BLUE if accent else BG, fg=INK, activebackground='#d6eafb', activeforeground=INK,
                      disabledforeground='#9aa7b1', relief='flat', bd=0, padx=18, pady=9, cursor='hand2',
                      highlightthickness=1, highlightbackground=BLUE if accent else BORDER,
                      highlightcolor=BLUE, takefocus=True)
        b.pack(side='right' if right else 'left', padx=4)
        return b

    def update_widget(self, widget, **options):
        previous = self.widget_states.setdefault(widget, {})
        changed = {key: value for key, value in options.items() if previous.get(key) != value}
        if changed:
            widget.configure(**changed)
            previous.update(changed)

    def save(self):
        DATA.mkdir(parents=True, exist_ok=True)
        temporary = DATA / 'settings.tmp'
        temporary.write_text(json.dumps(self.cfg, indent=2), encoding='utf-8')
        temporary.replace(DATA / 'settings.json')

    def start(self, mode='live'):
        if self.closing:
            return
        self.pending_start = mode
        if self.engine and self.engine.is_alive():
            self.engine.stop()
            self.root.after(30, self.finish_switch)
        else:
            self.finish_switch()

    def toggle_demo(self):
        if self.pending_start == 'demo' or (self.mode == 'demo' and self.engine and self.engine.is_alive() and not self.engine.stop_event.is_set()):
            self.disconnect()
        else:
            self.start('demo')

    def finish_switch(self):
        if self.closing or self.pending_start is None:
            return
        if self.engine and self.engine.is_alive():
            self.root.after(30, self.finish_switch)
            return
        mode = self.pending_start
        self.pending_start = None
        self.mode = mode
        self.history.clear()
        self.latest = None
        self.pose = [0.0] * 6
        self.message = ''
        self.plot_limits = [10.] * 3 + [.5] * 3
        self.limit_updated = [0.] * 6
        self.engine = DemoEngine(period=.01) if mode == 'demo' else Engine(self.cfg['host'], self.cfg['port'], 'HEX QC', period=self.cfg['poll_ms'] / 1000)
        self.engine.start()
        logging.info('Source switched to %s', mode)

    def disconnect(self):
        self.pending_start = None
        if self.engine:
            self.engine.stop()

    def zero(self):
        if self.engine:
            try:
                self.engine.command('zero')
                self.message = 'Demo zero requested' if self.mode == 'demo' else 'Zero requested'
            except queue.Full:
                self.message = 'Command queue full; try again'

    def record(self):
        if self.engine:
            prefix = 'demo_' if self.mode == 'demo' else 'recording_'
            path = DATA / (prefix + time.strftime('%Y%m%d_%H%M%S') + f'_{time.time_ns() % 1000000}.csv')
            try:
                self.engine.command('record', str(path))
            except queue.Full:
                self.message = 'Command queue full; try again'

    def settings(self):
        win = tk.Toplevel(self.root)
        win.title('Viewer Settings')
        win.configure(bg=WHITE)
        win.resizable(False, False)
        win.transient(self.root)
        variables = {}

        def label(text, row, col=0, span=1):
            tk.Label(win, text=text, fg=INK, bg=WHITE, font=('Segoe UI', 10)).grid(row=row, column=col, columnspan=span, padx=14, pady=7, sticky='w')
        label('HEX QC sensor  /  Modbus TCP  /  Unit ID 64', 0, span=6)
        for r, (key, title) in enumerate([('host', 'Compute Box IP'), ('port', 'TCP port'), ('poll_ms', 'PC polling interval (ms)')], 1):
            label(title, r)
            variables[key] = tk.StringVar(value=str(self.cfg[key]))
            tk.Entry(win, textvariable=variables[key], width=22, relief='solid', bd=1).grid(row=r, column=1, columnspan=2, sticky='w')
        label('PC polling does not change the device Cycle Time or filter.', 4, span=6)
        for c, heading in enumerate(['Axis', 'Invert', 'Gain *', 'Deadband', 'Smoothing (s)', 'Max *']):
            label(heading, 5, c)
        axisvars = []
        for i, axis in enumerate(self.cfg['axes']):
            label(AXES[i], 6 + i)
            av = {'invert': tk.BooleanVar(value=axis['invert'])}
            tk.Checkbutton(win, variable=av['invert'], bg=WHITE, activebackground=WHITE).grid(row=6 + i, column=1)
            for c, key in enumerate(['gain', 'deadband', 'smoothing', 'limit'], 2):
                av[key] = tk.StringVar(value=str(axis[key]))
                tk.Entry(win, textvariable=av[key], width=12, relief='solid', bd=1).grid(row=6 + i, column=c, padx=8, pady=5)
            axisvars.append(av)
        label('* Force: model units/N and model units. Torque: degrees/Nm and degrees.', 12, span=6)
        label('Graphic settings leave the measured values, plots and CSV unchanged.', 13, span=6)

        def apply():
            try:
                cfg = copy.deepcopy(self.cfg)
                cfg.update(host=variables['host'].get().strip(), port=int(variables['port'].get()), poll_ms=float(variables['poll_ms'].get()))
                cfg['axes'] = [{k: (v.get() if k == 'invert' else float(v.get())) for k, v in av.items()} for av in axisvars]
                validate(cfg)
                old = self.cfg
                self.cfg = cfg
                try:
                    self.save()
                except OSError:
                    self.cfg = old
                    raise
                win.destroy()
                restart_mode = self.pending_start
                if restart_mode is None and self.engine and self.engine.is_alive() and not self.engine.stop_event.is_set():
                    restart_mode = self.mode
                if restart_mode is not None:
                    self.start(restart_mode)
            except (ValueError, TypeError, OSError) as exc:
                messagebox.showerror('Settings', str(exc), parent=win)
        tk.Button(win, text='Save & apply', command=apply, bg=BLUE, fg=INK, relief='flat', padx=25, pady=10).grid(row=14, column=3, columnspan=3, pady=18)

    def panel(self, x, y, w, h, fill=WHITE, outline=BORDER, radius=12):
        r = min(radius, w / 2, h / 2)
        return self.canvas.create_polygon(x+r,y,x+w-r,y,x+w,y,x+w,y+r,x+w,y+h-r,x+w,y+h,x+w-r,y+h,x+r,y+h,x,y+h,x,y+h-r,x,y+r,x,y,
                                          smooth=True, splinesteps=20, fill=fill, outline=outline)

    def graph(self, x, y, w, h, axis, now, visible):
        c = self.canvas
        seconds = float(self.plot_seconds.get())
        self.panel(x, y, w, h, radius=8)
        color = COLORS[axis % 3]
        c.create_line(x+14, y+12, x+14, y+27, fill=color, width=3)
        c.create_text(x+24, y+19, text=AXES[axis], anchor='w', fill=INK, font=('Segoe UI', 11, 'bold'))
        c.create_text(x+w-14, y+19, text='N' if axis < 3 else 'Nm', anchor='e', fill=MUTED, font=('Segoe UI', 9))
        gx, gy, gw, gh = x+49, y+38, w-64, h-63
        desired = nice_limit(max((abs(s[1][axis]) for s in visible), default=0), 10 if axis < 3 else .5)
        if desired > self.plot_limits[axis] or (desired < self.plot_limits[axis] and now-self.limit_updated[axis] > 3):
            self.plot_limits[axis] = desired
            self.limit_updated[axis] = now
        limit = self.plot_limits[axis]
        c.create_rectangle(gx, gy, gx+gw, gy+gh, fill='#fafcfd', outline='#c2ccd3')
        for i in range(9):
            yy = gy+gh*i/8
            c.create_line(gx, yy, gx+gw, yy, fill='#d0d9df' if i % 2 == 0 else '#e8edf0')
            if i % (4 if gh < 75 else 2) == 0:
                c.create_text(gx-7, yy, text=f'{limit*(1-i/4):g}', anchor='e', fill=MUTED, font=('Consolas', 8))
        for i in range(11):
            xx = gx+gw*i/10
            c.create_line(xx, gy, xx, gy+gh, fill='#d0d9df' if i % 2 == 0 else '#e8edf0')
            if i % 2 == 0:
                c.create_text(xx, gy+gh+13, text=f'{-seconds+i*seconds/10:g}', fill=MUTED, font=('Consolas', 8))
        c.create_line(gx, gy+gh/2, gx+gw, gy+gh/2, fill='#9aaab5')
        for segment in trace_segments(visible, axis, now-seconds, now, max(1, int(gw)), max(.15, self.cfg['poll_ms']/1000*3)):
            pts = [p for t, v in step_points(segment) for p in (gx+(t-now+seconds)/seconds*gw, gy+gh/2-v/limit*gh/2)]
            if len(pts) >= 4:
                c.create_line(*pts, fill=color, width=1.65, smooth=False)
            elif pts:
                c.create_oval(pts[0]-1, pts[1]-1, pts[0]+1, pts[1]+1, fill=color, outline=color)

    def frame(self):
        if self.closing:
            return
        now = time.perf_counter()
        dt = min(.1, now-self.last_frame)
        self.last_frame = now
        self.frame_times.append(now)
        state, detail, zero, hz, rtt, dropped, recording = 'Disconnected', '', '', 0, 0, 0, False
        if self.engine:
            batch, state, detail, zero, hz, rtt, dropped, recording = self.engine.snapshot()
            self.history.extend(batch)
            if batch:
                self.latest = batch[-1]
            if zero:
                self.message = zero
        while self.history and now-self.history[0][0] > 11:
            self.history.popleft()
        running = bool(self.engine and self.engine.is_alive() and not self.engine.stop_event.is_set())
        fresh = bool(self.latest and now-self.latest[0] < max(.5, self.cfg['poll_ms']/1000*2.5) and state in ('Live', 'Demo') and running)
        if state in ('Live', 'Demo') and not fresh:
            state, detail = ('Connecting', 'Waiting for data') if running else ('Disconnected', '')
        demo = fresh and self.mode == 'demo'
        vals = self.latest[1] if fresh else [0.] * 6
        self.pose = move(self.pose, vals, self.cfg['axes'], dt)
        badge_colors = {'Live': ('#196b4c', '#e6f4ed'), 'Demo': ('#246a9c', SOFT_BLUE), 'Error': ('#a54132', '#fceee9')}
        fg, bg = badge_colors.get(state, (MUTED, BG))
        self.update_widget(self.badge, text='  '+state.upper()+'  ', fg=fg, bg=bg)
        self.update_widget(self.source_label, text='Simulated input' if demo else ('HEX-H QC | cycle / filter (at connect): '+self.device_rate_text(fresh) if fresh else 'HEX-H QC sensor'))
        self.update_widget(self.zero_button, state='normal' if fresh else 'disabled')
        self.update_widget(self.disconnect_button, state='normal' if running or self.pending_start else 'disabled')
        self.update_widget(self.connect_button, state='disabled' if running and self.mode == 'live' else 'normal')
        self.update_widget(self.demo_button, text='Stop Demo' if demo else 'Demo', bg=SOFT_BLUE if demo else BG, fg='#246a9c' if demo else INK)
        self.update_widget(self.record_button, text='Stop CSV' if recording else 'Record CSV', fg='#ab4937' if recording else INK, state='normal' if running else 'disabled')
        c = self.canvas
        c.begin_frame()
        w, h = c.winfo_width(), c.winfo_height()
        if w > 300 and h > 300:
            gap = 14
            graphw = (w-gap)*.59
            bodyh = h-118
            # Advance the trace only when a real sample arrives.
            plot_now = self.latest[0] if fresh else now
            visible = [s for s in self.history if plot_now-float(self.plot_seconds.get()) <= s[0] <= plot_now]
            cw = (graphw-gap)/2
            rh = (bodyh-34-2*gap)/3
            c.create_text(3, 12, text='FORCE', anchor='w', fill=INK, font=('Segoe UI', 10, 'bold'))
            c.create_text(cw-4, 12, text='NEWTONS', anchor='e', fill=MUTED, font=('Segoe UI', 8))
            c.create_text(cw+gap+3, 12, text='TORQUE', anchor='w', fill=INK, font=('Segoe UI', 10, 'bold'))
            c.create_text(graphw-4, 12, text='NEWTON METRES', anchor='e', fill=MUTED, font=('Segoe UI', 8))
            for row in range(3):
                self.graph(1, 34+row*(rh+gap), cw-1, rh, row, plot_now, visible)
                self.graph(cw+gap, 34+row*(rh+gap), cw, rh, row+3, plot_now, visible)
            rx, rw = graphw+gap, w-graphw-gap-1
            self.panel(rx, 1, rw, bodyh)
            c.create_text(rx+24, 29, text='HEX QC + 3FG25', anchor='w', fill=INK, font=('Segoe UI', 17, 'bold'))
            c.create_text(rx+24, 56, text='6-AXIS FORCE / TORQUE', anchor='w', fill=MUTED, font=('Segoe UI', 9))
            c.create_line(rx+24, 76, rx+rw-24, 76, fill=BORDER)
            # Reserve the target strip in every mode; connecting/stopping Demo
            # must not change the camera scale or the fixed robot wrist position.
            stage_bottom = bodyh-92
            self.product_stage.draw((rx+6, 84, rw-12, stage_bottom-84), self.pose, fresh)
            if demo:
                info = self.engine.demo_info()
                target = info['target']
                c.create_line(rx+24, bodyh-83, rx+rw-24, bodyh-83, fill=BORDER)
                c.create_text(rx+24, bodyh-62, text='DEMO TARGET', anchor='w', fill=MUTED, font=('Segoe UI', 8, 'bold'))
                c.create_text(rx+rw-24, bodyh-62, text=info['phase'], anchor='e', fill='#246a9c', font=('Segoe UI', 9))
                tw = (rw-48)/3
                for i in range(3):
                    c.create_text(rx+24+i*tw, bodyh-31, text=f'{"XYZ"[i]}  {target[i]:+.1f} N', anchor='w', fill=COLORS[i], font=('Consolas', 11, 'bold'))
            rate = f'{hz:.1f}' if fresh and hz > 0 else '--'
            for i in range(6):
                tilew = (w-5*gap)/6
                x, y = i*(tilew+gap), h-99
                self.panel(x, y, tilew, 96, radius=9)
                c.create_oval(x+15, y+17, x+21, y+23, fill=COLORS[i % 3], outline='')
                c.create_text(x+30, y+21, text=AXES[i], anchor='w', fill=MUTED, font=('Segoe UI', 10, 'bold'))
                c.create_text(x+tilew-15, y+21, text='N' if i < 3 else 'Nm', anchor='e', fill=MUTED, font=('Segoe UI', 9))
                value = f'{vals[i]:+.1f}' if i < 3 else f'{vals[i]:+.2f}'
                c.create_text(x+14, y+47, text=value if fresh else '--', anchor='w', fill=INK if fresh else '#a2adb5', font=('Consolas', min(28, int(tilew/6)), 'bold'))
                capacity = (200, 200, 200, 20, 20, 13)[i]
                unit = 'N' if i < 3 else 'Nm'
                c.create_text(x+14, y+72, text=f'Min -{capacity} / Max +{capacity} {unit}', anchor='w',
                              fill=MUTED, font=('Segoe UI', 8))
                c.create_text(x+14, y+86, text=f'{"Demo" if demo else "RX"} {rate} Hz', anchor='w',
                              fill=MUTED, font=('Segoe UI', 8))
        if self.message:
            status = self.message
        elif demo:
            status = f'Demo  ·  {hz:.0f} samples/s  ·  {self.plot_seconds.get()} s view'
        elif fresh:
            status = f'{hz:.0f} samples/s  ·  RTT {rtt:.1f} ms  ·  {self.plot_seconds.get()} s view'
        elif state in ('Connecting', 'Error'):
            status = detail
        else:
            status = 'Ready  ·  Connect to HEX QC or start Demo'
        c.end_frame()
        fps = ((len(self.frame_times)-1)/(now-self.frame_times[0]) if len(self.frame_times) > 1 else 0)
        status += f'  |  Target {100 if self.mode == "demo" else 1000/self.cfg["poll_ms"]:g} Hz  |  UI {fps:.0f} fps  |  HEX-H: single-axis limits; combined loads derate'
        self.update_widget(self.footer, text=status)
        self.root.after(max(1, round(min(1000/120, self.cfg['poll_ms'])-(time.perf_counter()-now)*1000)), self.frame)

    def device_rate_text(self, fresh):
        if self.mode == 'demo':
            return 'simulated'
        config = self.engine.device_config() if self.engine and fresh else None
        if config is None:
            return '-- / --'
        _, filter_code, cycle_ms = config
        rate = f'{1000/cycle_ms:g} Hz' if 2 <= cycle_ms <= 254 else ('stopped' if cycle_ms == 0 else 'unknown')
        filters = {0: 'off', 1: '500 Hz', 2: '150 Hz', 3: '50 Hz', 4: '15 Hz', 5: '5 Hz', 6: '1.5 Hz'}
        return rate+' / '+filters.get(filter_code, 'unknown')

    def close(self):
        self.closing = True
        if self.engine:
            self.engine.stop()
        self.wait_close()

    def wait_close(self):
        if self.engine and self.engine.is_alive():
            self.root.after(30, self.wait_close)
        else:
            self.root.destroy()


def main():
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--live', action='store_true', help='Connect to HEX QC immediately')
    modes.add_argument('--demo', action='store_true', help='Start random-target demo without hardware')
    parser.add_argument('--smoke-test', action='store_true', help='Run UI for 5 seconds, log a snapshot, then close')
    args = parser.parse_args()
    if os.name == 'nt':
        for key, folder in [('TCL_LIBRARY', 'tcl8.6'), ('TK_LIBRARY', 'tk8.6')]:
            path = Path(os.environ.get(key, str(Path(sys.base_prefix)/'tcl'/folder)))
            if path.is_dir() and not str(path).startswith(('//?/', '\\\\?\\')):
                os.environ[key] = '//?/'+str(path.resolve()).replace('\\', '/')
    try:
        DATA.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(DATA/'viewer.log', maxBytes=2_000_000, backupCount=3, encoding='utf-8')
        logging.basicConfig(level=logging.INFO, handlers=[handler], format='%(asctime)s %(levelname)s %(message)s')
    except OSError as exc:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror('Cannot write data', f'{DATA}\n{exc}\nMove the distribution to a writable folder.')
        root.destroy()
        return
    logging.info('Viewer 0.6.2 started; hidden upper anchor and fixed camera; no automatic device configuration writes')
    root = tk.Tk()
    root.report_callback_exception = lambda exc, val, tb: (logging.error('UI exception', exc_info=(exc, val, tb)), messagebox.showerror('Viewer error', str(val)))
    app = Viewer(root, connect=args.live, demo=args.demo)
    if args.smoke_test:
        def finish_smoke():
            result = {'state': app.engine.state if app.engine else 'Disconnected', 'samples': app.engine.count if app.engine else 0,
                      'hz': app.engine.hz if app.engine else 0, 'canvas_items': len(app.canvas.find_all()),
                      'fresh': bool(app.latest and time.perf_counter()-app.latest[0] < .5)}
            (DATA/'smoke_test.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
            logging.info('Smoke test: %s', result)
            app.close()
        root.after(5000, finish_smoke)
    root.mainloop()


if __name__ == '__main__':
    main()
