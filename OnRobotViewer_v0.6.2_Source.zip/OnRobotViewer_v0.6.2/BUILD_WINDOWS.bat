@echo off
setlocal
cd /d "%~dp0"
py -3 restore_assets.py
if errorlevel 1 goto fail
py -3 -m venv .build-venv
if errorlevel 1 goto fail
".build-venv\Scripts\python.exe" -m pip install -r requirements-build.txt
if errorlevel 1 goto fail
".build-venv\Scripts\python.exe" -m unittest -v test_viewer test_demo test_mount
if errorlevel 1 goto fail
".build-venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --windowed --noupx --add-data "assets;assets" --name OnRobotViewer viewer.py
if errorlevel 1 goto fail
copy /y README_KO.md dist\OnRobotViewer\README_KO.md >nul
copy /y START_VIEWER.bat dist\OnRobotViewer\START_VIEWER.bat >nul
copy /y START_DEMO.bat dist\OnRobotViewer\START_DEMO.bat >nul
echo Build complete: dist\OnRobotViewer\OnRobotViewer.exe
pause
exit /b 0
:fail
echo Build failed. Review the error above.
pause
exit /b 1
