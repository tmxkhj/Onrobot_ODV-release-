import collections
import ctypes
import csv
import logging
import os
import queue
import threading
import time
from protocol import Client, PROFILES, decode


class Engine(threading.Thread):
    def __init__(self, host, port, profile, period=0.01):
        super().__init__(daemon=True)
        self.host, self.port, self.profile = host, port, profile
        self.period = period
        self.stop_event = threading.Event()
        self.commands = queue.Queue(maxsize=8)
        self.lock = threading.Lock()
        self.samples = collections.deque(maxlen=3000)
        self.state, self.detail, self.zero_result = 'Connecting', '', ''
        self.latest = None
        self.hex_config = None
        self.count = self.dropped = 0
        self.hz = self.rtt = 0.0
        self.recording = False
        self.record_file = None

    def status(self, state, detail):
        with self.lock:
            changed = (self.state, self.detail) != (state, detail)
            self.state, self.detail = state, detail
        if changed:
            logging.info('%s: %s', state, detail)

    def device_config(self):
        with self.lock:
            return self.hex_config

    def snapshot(self):
        with self.lock:
            batch = list(self.samples)
            self.samples.clear()
            return batch, self.state, self.detail, self.zero_result, self.hz, self.rtt, self.dropped, self.recording

    def command(self, command, value=None):
        self.commands.put_nowait((command, value))

    def stop(self):
        self.stop_event.set()

    def publish(self, values):
        now = time.perf_counter()
        sample = (now, values)
        with self.lock:
            if len(self.samples) == self.samples.maxlen:
                self.dropped += 1
            self.samples.append(sample)
            self.latest = sample
            self.count += 1
        if self.record_file:
            try:
                self.writer.writerow((time.time(), now, self.profile, *values))
                if self.count % 100 == 0:
                    self.record_file.flush()
            except OSError as exc:
                logging.exception('CSV recording failed')
                self.finish_record()
                with self.lock:
                    self.zero_result = f'CSV error: {exc}'

    def finish_record(self):
        if self.record_file:
            try:
                self.record_file.close()
            except OSError:
                logging.exception('CSV close failed')
        self.record_file = None
        self.recording = False

    def run(self):
        timer_active = False
        if os.name == 'nt':
            timer_active = ctypes.windll.winmm.timeBeginPeriod(1) == 0
        client = None
        rate_start = time.perf_counter()
        rate_count, next_health = 0, 0
        sensor_good = False
        try:
            while not self.stop_event.is_set():
                if client is None:
                    self.status('Connecting', f'{self.host}:{self.port} / Unit {PROFILES[self.profile][0]}')
                    try:
                        client = Client(self.host, self.port, PROFILES[self.profile][0])
                        # Device identity check prevents writes to a different gripper at unit 65.
                        if self.profile.startswith('RG2'):
                            identity = client.read(1536, 1)[0]
                            logging.info('Product code @1536 = 0x%04X', identity)
                            if identity != 0x22:
                                raise ValueError(f'Expected RG2-FT product 0x22; received 0x{identity:04X}')
                        else:
                            config = client.read(0, 3)
                            with self.lock:
                                self.hex_config = config
                            logging.info('HEX read-only config 0..2: %s', config)
                        next_health = 0
                    except Exception as exc:
                        if client:
                            client.close()
                        client = None
                        self.status('Error', str(exc)+' | retry in 2 s')
                        # A queued Zero must never survive a failed connection.
                        self.reject_pending()
                        self.stop_event.wait(2)
                        continue
                tick = time.perf_counter()
                try:
                    while not self.commands.empty():
                        cmd, value = self.commands.get_nowait()
                        if cmd == 'zero':
                            if self.profile == 'RG2-FT Right':
                                self.zero_result = 'Right status mapping unverified; use Left profile for hardware Zero'
                            elif sensor_good and self.latest and tick-self.latest[0] < 0.5:
                                self.zero_result = 'Zero pending'
                                try:
                                    client.zero()
                                    self.zero_result = 'Zero acknowledged (FC06); check unloaded readings'
                                    logging.info('Zero ACK: unit=%s address=0 value=1', client.unit)
                                except Exception:
                                    self.zero_result = 'Zero failed / outcome unknown; NOT retried'
                                    raise
                            else:
                                self.zero_result = 'Zero rejected: no healthy current sensor data'
                        elif cmd == 'record':
                            if self.recording:
                                self.finish_record()
                            else:
                                try:
                                    self.record_file = open(value, 'x', newline='', encoding='utf-8')
                                    self.writer = csv.writer(self.record_file)
                                    self.writer.writerow(('unix_time','monotonic_time','profile','Fx_N','Fy_N','Fz_N','Tx_Nm','Ty_Nm','Tz_Nm'))
                                    self.recording = True
                                except OSError as exc:
                                    self.zero_result = f'CSV error: {exc}'
                                    logging.exception('Cannot open recording')
                    unit, address, status_address = PROFILES[self.profile]
                    if tick >= next_health:
                        health = client.read(status_address, 2)
                        logging.info('Health unit=%d @%d=%s', unit, status_address, health)
                        # HEX 257 is ambiguous in supplied table: log it, use detailed 256 definition.
                        sensor_good = all(v == 0 for v in (health if self.profile == 'RG2-FT Left' else health[:1]))
                        next_health = tick+1
                    words = client.read(address, 6)
                    values = decode(words)
                    self.rtt = (time.perf_counter()-tick)*1000
                    if not sensor_good:
                        self.status('Error', f'Sensor status nonzero: {health}')
                        self.stop_event.wait(self.period)
                        continue
                    note = ' / RIGHT STATUS UNVERIFIED' if self.profile == 'RG2-FT Right' else ''
                    self.status('Live', f'{self.profile} / Unit {unit} / @{address}'+note)
                    self.publish(values)
                    rate_count += 1
                    elapsed = tick-rate_start
                    if elapsed >= 1:
                        self.hz = rate_count/elapsed
                        rate_count, rate_start = 0, tick
                except Exception as exc:
                    logging.exception('Acquisition failure')
                    self.status('Error', str(exc))
                    sensor_good = False
                    with self.lock:
                        self.hex_config = None
                    if client:
                        client.close()
                    client = None
                    self.reject_pending()
                    self.stop_event.wait(2)
                self.stop_event.wait(max(0, self.period-(time.perf_counter()-tick)))
        finally:
            if client:
                client.close()
            self.finish_record()
            self.status('Disconnected', 'Stopped')
            if timer_active:
                ctypes.windll.winmm.timeEndPeriod(1)

    def reject_pending(self):
        while not self.commands.empty():
            cmd, _ = self.commands.get_nowait()
            if cmd == 'zero':
                self.zero_result = 'Zero cancelled: connection lost; NOT retried'
