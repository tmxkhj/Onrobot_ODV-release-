import tkinter as tk
import time
from viewer import Viewer
root=tk.Tk()
errors=[]
root.report_callback_exception=lambda *args: errors.append(str(args))
app=Viewer(root,demo=True)
for size in ('1440x900','1100x720'):
    root.geometry(size)
    end=time.perf_counter()+2.5
    while time.perf_counter()<end:
        root.update()
        time.sleep(.001)
    c=app.canvas
    labels=[i for i in c.find_all() if c.type(i)=='text' and c.itemcget(i,'text').startswith(('Min -','Demo '))]
    assert len(labels)==12, len(labels)
    for item in labels:
        x1,y1,x2,y2=c.bbox(item)
        assert 0 <= x1 < x2 <= c.winfo_width()
        assert 0 <= y1 < y2 <= c.winfo_height()
        tilew=(c.winfo_width()-5*14)/6
        assert x2-x1 < tilew-20, (size,c.itemcget(item,'text'),x2-x1,tilew)
    fps=(len(app.frame_times)-1)/(app.frame_times[-1]-app.frame_times[0])
    print(size,'12 labels fit; RX',round(app.engine.hz,1),'Hz; UI',round(fps,1),'fps')
assert not errors, errors
app.close()
while app.engine.is_alive():
    root.update()
    time.sleep(.005)
print('UI validation passed')
