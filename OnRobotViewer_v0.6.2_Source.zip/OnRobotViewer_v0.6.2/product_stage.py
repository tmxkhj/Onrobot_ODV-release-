"""Antialiased product stage composited as one Tk image per frame."""
import tkinter as tk
import time
from PIL import Image, ImageDraw
from graphics import draw_model


class ProductStage:
    def __init__(self, canvas):
        self.canvas = canvas
        self.photo = tk.PhotoImage(master=canvas)
        self.last_image = None
        self.signature = None
        self.legend = []
        self.last_render = 0.0

    def draw(self, bounds, pose, active):
        x,y,w,h = bounds
        width,height = max(1,round(w)),max(1,round(h))
        signature=(tuple(round(v,4) for v in pose),tuple(bounds),active)
        self.canvas.create_image(x,y,anchor='nw',image=self.photo)
        now = time.perf_counter()
        # Keep expensive model rasterization at 30 fps; graphs can update faster.
        resized = self.signature is None or signature[1:] != self.signature[1:]
        if signature != self.signature and (resized or now-self.last_render >= 1/30):
            self.last_render = now
            self.signature = signature
            # Limit supersampling on large presentation displays so resolution
            # does not multiply the raster workload by four without a benefit.
            aa = 2 if width*height < 250000 else 1.25
            image = Image.new('RGB',(round(width*aa),round(height*aa)),'white')
            painter = ImageDraw.Draw(image)
            legend = []
            class Surface:
                def create_polygon(self,*coords,**opts):
                    points=[((coords[i]-x)*aa,(coords[i+1]-y)*aa) for i in range(0,len(coords),2)]
                    painter.polygon(points,fill=opts.get('fill'),outline=opts.get('outline') or None)
                def create_oval(self,*coords,**opts):
                    box=((coords[0]-x)*aa,(coords[1]-y)*aa,(coords[2]-x)*aa,(coords[3]-y)*aa)
                    painter.ellipse(box,fill=opts.get('fill') or None,outline=opts.get('outline') or None,width=max(1,round(opts.get('width',1)*aa)))
                def create_line(self,*coords,**opts):
                    legend.append(('line',coords,opts))
                def create_text(self,*coords,**opts):
                    legend.append(('text',coords,opts))
            draw_model(Surface(),bounds,pose,active)
            self.last_image = image.resize((width,height),Image.Resampling.BILINEAR)
            pixels=f'P6\n{width} {height}\n255\n'.encode()+self.last_image.tobytes()
            self.photo.configure(data=pixels,format='PPM')
            self.legend=legend
        for kind,coords,opts in self.legend:
            getattr(self.canvas,'create_'+kind)(*coords,**opts)
