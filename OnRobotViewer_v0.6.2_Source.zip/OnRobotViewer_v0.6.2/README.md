# OnRobot HEX QC Viewer 0.6.1

최종 소스와 Windows EXE 자동 빌드 구성입니다. HEX QC + 3FG25 표시, 6개 독립 그래프, Demo, 고정 카메라를 포함합니다.

## Python 없이 Windows 실행

GitHub **Actions → Build Windows distribution**의 성공한 실행을 열고 **OnRobotViewer-v0.6.1-Windows-x64** artifact를 다운로드하세요. 전체 압축을 풀고 `OnRobotViewer.exe`를 실행합니다. 장비 없는 시연은 `START_DEMO.bat`입니다. `_internal` 폴더를 반드시 함께 유지하세요. 실행에는 Python 설치와 인터넷 연결이 필요하지 않습니다.

빌드는 최종 소스의 자동 시험 24개와 EXE 미연결/Demo 시작·종료 시험을 수행합니다. Actions가 성공하기 전에는 해당 EXE를 검증 완료로 간주하지 마세요. 실물 HEX QC 연결은 별도 현장 확인이 필요합니다.

## 소스 실행 및 클라우드 설정

```sh
python restore_assets.py
python -m pip install -r requirements.txt
python viewer.py --demo
```

Linux 클라우드 개발 환경에서는 Python 3.12 이상, Tcl/Tk, GUI 표시 서버가 필요합니다. Debian/Ubuntu에서 관리자 권한이 있으면 `sudo apt-get update && sudo apt-get install -y python3-tk xvfb`로 설치합니다. GUI 시험은 `xvfb-run -a python viewer.py --demo --smoke-test`, 프로토콜·그래픽 자동 시험은 `python -m unittest -v test_viewer test_demo test_mount`입니다. Windows EXE 빌드는 Linux 대신 포함된 Windows Actions를 사용하세요.

`assets/*.png.b64`는 원본 로고 PNG의 손실 없는 전송본입니다. 실행 전 `restore_assets.py`가 PNG를 복원합니다. 소스는 v0.6.1 그대로이며 수집·시각화 동작을 변경하지 않았습니다.

## 검증 범위

로컬 Windows에서 자동 시험 24개 통과와 EXE 빌드 성공을 확인했습니다. 회사 Microsoft Defender 정책(이벤트 1121, 규칙 01443614-CD74-433A-B99E-2ECDC07BFC25)이 로컬 EXE의 실행과 ZIP 포장을 차단했으므로 로컬 EXE 실행은 미검증입니다. 클라우드 산출물의 실행 허용도 대상 PC의 보안 정책에 따릅니다.

자세한 연결 절차와 과거 검증 기록은 README_KO.md와 VALIDATION_KO.md를 참조하세요. 원본 장비 로그·개인 설정·회사 기밀 PDF는 포함하지 않습니다.
