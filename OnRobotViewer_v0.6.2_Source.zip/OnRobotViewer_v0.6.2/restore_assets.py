"""Restore original PNG assets from their lossless base64 transport files."""
import base64
from pathlib import Path

for source in (Path(__file__).resolve().parent / 'assets').glob('*.png.b64'):
    source.with_suffix('').write_bytes(base64.b64decode(source.read_text(), validate=True))
