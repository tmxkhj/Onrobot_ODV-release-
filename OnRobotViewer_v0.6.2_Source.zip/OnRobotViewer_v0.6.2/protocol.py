"""Compute Box Modbus TCP. Addresses are zero-based PDU addresses."""
import socket
import struct
import time


class ModbusError(Exception):
    pass


def signed16(word):
    return word - 65536 if word & 0x8000 else word


def decode(words):
    if len(words) != 6:
        raise ValueError('Six registers required')
    return tuple(signed16(w) / (10 if i < 3 else 100) for i, w in enumerate(words))


PROFILES = {
    'RG2-FT Left': (65, 259, 256),
    'RG2-FT Right': (65, 268, 266),
    'HEX QC': (64, 259, 256),
}


class Client:
    """Single owner/thread; one in-flight transaction; deadline includes fragments."""
    def __init__(self, host, port=502, unit=65, timeout=0.7):
        self.unit, self.timeout, self.tid = unit, timeout, 0
        self.sock = socket.create_connection((host, port), timeout)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    def close(self):
        self.sock.close()

    def _recv(self, count, deadline):
        result = bytearray()
        while len(result) < count:
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                raise TimeoutError('Modbus response deadline exceeded')
            self.sock.settimeout(remaining)
            part = self.sock.recv(count-len(result))
            if not part:
                raise ConnectionError('Compute Box closed the connection')
            result.extend(part)
        return bytes(result)

    def exchange(self, pdu):
        self.tid = (self.tid + 1) & 65535
        deadline = time.perf_counter() + self.timeout
        self.sock.settimeout(self.timeout)
        self.sock.sendall(struct.pack('>HHHB', self.tid, 0, len(pdu)+1, self.unit) + pdu)
        tid, proto, length, unit = struct.unpack('>HHHB', self._recv(7, deadline))
        if (tid, proto, unit) != (self.tid, 0, self.unit) or not 2 <= length <= 254:
            raise ModbusError('Invalid MBAP transaction/protocol/unit/length')
        reply = self._recv(length-1, deadline)
        if reply[0] == (pdu[0] | 0x80):
            if len(reply) != 2:
                raise ModbusError('Malformed exception response')
            raise ModbusError(f'Modbus exception 0x{reply[1]:02X}')
        if reply[0] != pdu[0]:
            raise ModbusError('Unexpected function code')
        return reply

    def read(self, address, count):
        if not 1 <= count <= 125 or not 0 <= address <= 65536-count:
            raise ValueError('Invalid read range')
        reply = self.exchange(struct.pack('>BHH', 3, address, count))
        if len(reply) != count*2+2 or reply[1] != count*2:
            raise ModbusError('Unexpected register byte count')
        return struct.unpack('>'+'H'*count, reply[2:])

    def zero(self):
        # Intentionally no generic public write method or automatic replay.
        pdu = struct.pack('>BHH', 6, 0, 1)
        if self.exchange(pdu) != pdu:
            raise ModbusError('Zero write echo mismatch; outcome unknown')
