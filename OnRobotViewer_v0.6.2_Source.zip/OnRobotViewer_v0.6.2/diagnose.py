"""Read-only diagnostics. Close the viewer/other Modbus clients before running."""
import argparse
import json
from pathlib import Path
import statistics
import time
from protocol import Client, PROFILES, decode


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host',default='192.168.1.1')
    p.add_argument('--port',type=int,default=502)
    p.add_argument('--profile',choices=list(PROFILES),default='RG2-FT Left')
    p.add_argument('--seconds',type=float,default=10)
    p.add_argument('--output',default='diagnostic.json')
    args=p.parse_args()
    unit,address,status=PROFILES[args.profile]
    report={'host':args.host,'port':args.port,'profile':args.profile,'unit':unit,'writes':0,
            'time':time.strftime('%Y-%m-%d %H:%M:%S'),'snapshots':[]}
    client=None
    try:
        client=Client(args.host,args.port,unit,2)
        if unit==65:
            report['product_code']=client.read(1536,1)[0]
            if report['product_code']!=0x22:raise ValueError('Not an RG2-FT')
        else:report['zero_filter_cycle']=client.read(0,3)
        durations=[];count=0;start=time.perf_counter();deadline=start
        low=[float('inf')]*6;high=[float('-inf')]*6
        while time.perf_counter()-start<args.seconds:
            t=time.perf_counter()
            raw=client.read(259 if unit==64 else 256,6 if unit==64 else 18)
            durations.append((time.perf_counter()-t)*1000)
            words=raw if unit==64 else raw[address-256:address-256+6]
            values=decode(words)
            low=[min(a,b) for a,b in zip(low,values)];high=[max(a,b) for a,b in zip(high,values)]
            if count%100==0:
                report['snapshots'].append({'elapsed_s':t-start,'raw':raw,'selected_axes':values})
            count+=1;deadline+=.01
            time.sleep(max(0,deadline-time.perf_counter()))
            if time.perf_counter()-deadline>.01:deadline=time.perf_counter()
        elapsed=time.perf_counter()-start
        report.update(samples=count,elapsed_s=elapsed,polls_per_second=count/elapsed,latency_mean_ms=statistics.mean(durations),
                      latency_p95_ms=sorted(durations)[int(len(durations)*.95)],latency_max_ms=max(durations),min=low,max=high)
        report['status_raw']=client.read(status,2)
    except Exception as exc:
        report['error']=f'{type(exc).__name__}: {exc}'
    finally:
        if client:client.close()
    Path(args.output).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    return 1 if 'error' in report else 0


if __name__=='__main__':raise SystemExit(main())
