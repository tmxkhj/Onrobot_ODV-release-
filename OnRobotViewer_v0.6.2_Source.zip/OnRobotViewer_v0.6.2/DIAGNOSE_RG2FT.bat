@echo off
cd /d "%~dp0"
echo Close the viewer and all other Modbus clients before continuing.
pause
py -3 diagnose.py --host 192.168.1.1 --profile "RG2-FT Left" --output diagnostic.json
pause
