"""Plot helpers. Decimation preserves sample order and communication gaps."""
import math


def nice_limit(peak, minimum):
    target=max(minimum,peak*1.1)
    base=10**math.floor(math.log10(target))
    return next(n*base for n in (1,2,5,10) if n*base>=target)


def trace_segments(samples, axis, start, end, pixels, max_gap):
    """Return first/min/max/last in chronological order within each pixel.

    A missing interval ends a segment before binning, so no artificial line
    bridges a communication outage. Input must be chronological.
    Exactly flat runs need only their two endpoints; their geometry is identical.
    """
    result=[];segment=[];bucket=[];pixel=None;last_time=None
    def flush_bucket():
        if bucket:
            chosen={0,len(bucket)-1,
                    min(range(len(bucket)),key=lambda i:bucket[i][1]),
                    max(range(len(bucket)),key=lambda i:bucket[i][1])}
            for i in sorted(chosen):
                point=bucket[i]
                if len(segment)>=2 and segment[-2][1]==segment[-1][1]==point[1]:
                    segment[-1]=point
                else:
                    segment.append(point)
            bucket.clear()
    for timestamp,values in samples:
        if timestamp<start or timestamp>end:continue
        if last_time is not None and timestamp-last_time>max_gap:
            flush_bucket()
            if segment:result.append(segment)
            segment=[];pixel=None
        new_pixel=min(pixels-1,max(0,int((timestamp-start)/(end-start)*pixels)))
        if new_pixel!=pixel:
            flush_bucket();pixel=new_pixel
        bucket.append((timestamp,values[axis]));last_time=timestamp
    flush_bucket()
    if segment:result.append(segment)
    return result


def step_points(segment):
    """Hold each received value until the next timestamp; never interpolate."""
    if not segment:
        return []
    result = [segment[0]]
    for timestamp, value in segment[1:]:
        result.append((timestamp, result[-1][1]))
        result.append((timestamp, value))
    return result
