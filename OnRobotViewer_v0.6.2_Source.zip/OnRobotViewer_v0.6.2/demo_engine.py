"""Local exhibition input: independent random targets, fast moves and holds.

This module deliberately has no protocol/client dependency. Demo CSV files use
the same columns as live recordings and explicitly identify their source.
"""
import collections
import csv
import ctypes
import logging
import math
import os
import queue
import random
import threading
import time


class RandomTargets:
    """A time-based, bounded trajectory that can also be tested without a clock."""

    def __init__(self, seed=None):
        self.random = random.Random(seed)
        self.reset(0.0)

    def reset(self, now):
        self.origin = self.target = (0.0,) * 6
        self.phase = 'Holding'
        self.progress = 1.0
        self.phase_start = now
        self.phase_end = now + 1.0

    def _next_target(self):
        force = [self.random.uniform(-30.0, 30.0) for _ in range(3)]
        # Isolated random axes make the mapping easy to understand; mixed-axis
        # targets show the combined movement. Neither pattern is periodic.
        if self.random.random() < 0.45:
            axis = self.random.randrange(3)
            strength = self.random.uniform(12.0, 30.0)
            force = [0.0] * 3
            force[axis] = strength * self.random.choice((-1, 1))
        torque = [self.random.uniform(-1.1, 1.1) for _ in range(3)]
        return tuple(force + torque)

    def values_at(self, now):
        while now >= self.phase_end:
            boundary = self.phase_end
            if self.phase == 'Holding':
                self.origin = self.target
                self.target = self._next_target()
                self.phase = 'Moving'
                duration = self.random.uniform(.02, .06)
            else:
                self.origin = self.target
                self.phase = 'Holding'
                duration = self.random.uniform(1.4, 2.3)
            self.phase_start = boundary
            self.phase_end = boundary + duration
        if self.phase == 'Holding':
            self.progress = 1.0
            return self.target
        fraction = max(0.0, min(1.0, (now-self.phase_start) / (self.phase_end-self.phase_start)))
        self.progress = fraction
        # Short linear transitions expose abrupt changes without fabricated sensor noise.
        blend = fraction
        return tuple(a+(b-a)*blend for a, b in zip(self.origin, self.target))


class DemoEngine(threading.Thread):
    """Engine-compatible 100 Hz source, with zero and CSV controls."""

    def __init__(self, period=0.01, seed=None):
        if not math.isfinite(period) or period <= 0:
            raise ValueError('Demo period must be positive and finite')
        super().__init__(daemon=True)
        self.period = period
        self.profile = 'DEMO'
        self.stop_event = threading.Event()
        self.commands = queue.Queue(maxsize=8)
        self.lock = threading.Lock()
        self.samples = collections.deque(maxlen=3000)
        self.state, self.detail, self.zero_result = 'Demo', 'Random targets / Holding', ''
        self.latest = None
        self.count = self.dropped = 0
        self.hz = self.rtt = 0.0
        self.recording = False
        self.record_file = None
        self.trajectory = RandomTargets(seed)
        self._demo_info = {'target': self.trajectory.target, 'phase': 'Holding', 'progress': 1.0}

    def snapshot(self):
        with self.lock:
            batch = list(self.samples)
            self.samples.clear()
            return batch, self.state, self.detail, self.zero_result, self.hz, self.rtt, self.dropped, self.recording

    def command(self, command, value=None):
        self.commands.put_nowait((command, value))

    def demo_info(self):
        with self.lock:
            return dict(self._demo_info)

    def stop(self):
        self.stop_event.set()

    def finish_record(self):
        if self.record_file:
            try:
                self.record_file.close()
            except OSError:
                logging.exception('Demo CSV close failed')
        self.record_file = None
        with self.lock:
            self.recording = False

    def _commands(self, elapsed):
        while True:
            try:
                command, value = self.commands.get_nowait()
            except queue.Empty:
                break
            if command == 'zero':
                self.trajectory.reset(elapsed)
                with self.lock:
                    # Discard unconsumed pre-zero samples so the next UI frame
                    # sees the new baseline, including if the UI was busy.
                    self.samples.clear()
                    self.zero_result = 'Demo zero complete'
            elif command == 'record':
                if self.recording:
                    self.finish_record()
                else:
                    try:
                        self.record_file = open(value, 'x', newline='', encoding='utf-8')
                        self.writer = csv.writer(self.record_file)
                        self.writer.writerow(('unix_time', 'monotonic_time', 'profile', 'Fx_N', 'Fy_N', 'Fz_N', 'Tx_Nm', 'Ty_Nm', 'Tz_Nm'))
                        with self.lock:
                            self.recording = True
                    except (OSError, TypeError) as exc:
                        self.finish_record()
                        with self.lock:
                            self.zero_result = f'CSV error: {exc}'
                        logging.exception('Cannot open demo recording')

    def _publish(self, now, values):
        sample = (now, values)
        with self.lock:
            if len(self.samples) == self.samples.maxlen:
                self.dropped += 1
            self.samples.append(sample)
            self.latest = sample
            self.count += 1
            self.detail = f'Random targets / {self.trajectory.phase}'
            self._demo_info = {'target': self.trajectory.target, 'phase': self.trajectory.phase, 'progress': self.trajectory.progress}
        if self.record_file:
            try:
                self.writer.writerow((time.time(), now, self.profile, *values))
                if self.count % 100 == 0:
                    self.record_file.flush()
            except OSError as exc:
                self.finish_record()
                with self.lock:
                    self.zero_result = f'CSV error: {exc}'
                logging.exception('Demo CSV recording failed')

    def run(self):
        timer_active = False
        if os.name == 'nt':
            # Windows' default wait granularity can reduce a 10 ms worker to
            # about 64 Hz. Match the live worker's temporary clock resolution.
            try:
                timer_active = ctypes.windll.winmm.timeBeginPeriod(1) == 0
            except (AttributeError, OSError):
                logging.warning('High-resolution demo timer unavailable')
        started = next_tick = rate_start = time.perf_counter()
        rate_count = 0
        logging.info('Demo started: local random targets')
        try:
            while not self.stop_event.is_set():
                now = time.perf_counter()
                elapsed = now-started
                self._commands(elapsed)
                self._publish(now, self.trajectory.values_at(elapsed))
                rate_count += 1
                if now-rate_start >= 1.0:
                    with self.lock:
                        self.hz = rate_count/(now-rate_start)
                    rate_start, rate_count = now, 0
                next_tick += self.period
                # A delayed worker skips missed ticks; it never emits a burst
                # of fictitious historical samples after a stall.
                if next_tick < now:
                    next_tick = now+self.period
                self.stop_event.wait(max(0.0, next_tick-time.perf_counter()))
        finally:
            self.finish_record()
            with self.lock:
                self.state, self.detail = 'Disconnected', 'Demo stopped'
            if timer_active:
                ctypes.windll.winmm.timeEndPeriod(1)
            logging.info('Demo stopped')
