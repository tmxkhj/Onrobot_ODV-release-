"""Retained Tk canvas: redraw only changed geometry and styles each frame."""
import tkinter as tk


def tcl_argument(value):
    """Quote one literal argument for a Tcl script, including list options."""
    if isinstance(value, (tuple, list)):
        value = ' '.join(tcl_argument(item) for item in value)
    text = str(value)
    for old, new in [('\\', '\\\\'), ('"', '\\"'), ('$', '\\$'), ('[', '\\['), (']', '\\]'), ('\n', '\\n'), ('\r', '\\r')]:
        text = text.replace(old, new)
    return '"'+text+'"'


class RetainedCanvas(tk.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._items = []
        self._cursor = 0
        self._pending = []
        self._reorder = False
        self._in_frame = False
        self._defaults = {}

    def begin_frame(self):
        self._cursor = 0
        self._pending = []
        self._reorder = False
        self._in_frame = True

    def end_frame(self):
        for entry in self._items[self._cursor:]:
            super().delete(entry['id'])
        del self._items[self._cursor:]
        if self._reorder:
            self._pending.extend(f'{self._w} raise {entry["id"]}' for entry in self._items)
        if self._pending:
            # Coordinates are numeric; all option values are literal arguments,
            # including text from a device error or a saved setting.
            self.tk.call('eval', '\n'.join(self._pending))
        self._in_frame = False

    def _draw(self, kind, coords, opts):
        if not self._in_frame:
            return self._create(kind, coords, opts)
        index = self._cursor
        self._cursor += 1
        coords = tuple(round(float(value), 2) for value in coords)
        if index >= len(self._items):
            item = self._create(kind, coords, opts)
            if kind not in self._defaults:
                self._defaults[kind] = {key: value[3] for key, value in self.itemconfigure(item).items()}
            self._items.append({'id': item, 'kind': kind, 'coords': coords, 'opts': opts})
            return item
        entry = self._items[index]
        if entry['kind'] != kind:
            super().delete(entry['id'])
            item = self._create(kind, coords, opts)
            if kind not in self._defaults:
                self._defaults[kind] = {key: value[3] for key, value in self.itemconfigure(item).items()}
            self._items[index] = {'id': item, 'kind': kind, 'coords': coords, 'opts': opts}
            self._reorder = True
            return item
        item = entry['id']
        if coords != entry['coords']:
            self._pending.append(f'{self._w} coords {item} '+' '.join(str(value) for value in coords))
            entry['coords'] = coords
        changed = {key: value for key, value in opts.items() if key not in entry['opts'] or value != entry['opts'][key]}
        changed.update({key: self._defaults[kind][key] for key in entry['opts'] if key not in opts})
        if changed:
            options = ' '.join('-'+key+' '+tcl_argument(value) for key, value in changed.items())
            self._pending.append(f'{self._w} itemconfigure {item} '+options)
        entry['opts'] = opts
        return item

    def create_polygon(self, *coords, **opts):
        return self._draw('polygon', coords, opts)

    def create_line(self, *coords, **opts):
        return self._draw('line', coords, opts)

    def create_rectangle(self, *coords, **opts):
        return self._draw('rectangle', coords, opts)

    def create_oval(self, *coords, **opts):
        return self._draw('oval', coords, opts)

    def create_text(self, *coords, **opts):
        return self._draw('text', coords, opts)

    def create_image(self, *coords, **opts):
        return self._draw('image', coords, opts)
