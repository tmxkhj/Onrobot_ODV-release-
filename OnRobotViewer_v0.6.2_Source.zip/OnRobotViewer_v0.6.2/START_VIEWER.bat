@echo off
setlocal
cd /d "%~dp0"
if exist "OnRobotViewer.exe" (
  start "" "OnRobotViewer.exe" %*
  exit /b
)
where py >nul 2>&1
if not errorlevel 1 (
  py -3 restore_assets.py
  py -3 viewer.py %*
) else (
  if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" (
    "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" viewer.py %*
  ) else (
    echo Python 3 with Tcl/Tk is required for this source release.
    echo Install Python or use a built OnRobotViewer.exe distribution.
    pause
    exit /b 1
  )
)
if errorlevel 1 pause
