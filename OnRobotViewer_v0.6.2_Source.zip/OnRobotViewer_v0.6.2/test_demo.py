import csv
import tempfile
import time
import unittest
from pathlib import Path
from demo_engine import DemoEngine, RandomTargets


class DemoTests(unittest.TestCase):
    def wait_for(self, predicate, timeout=1.0):
        deadline = time.perf_counter()+timeout
        while time.perf_counter() < deadline:
            if predicate():
                return
            time.sleep(0.005)
        self.fail('Demo worker did not reach the expected state')

    def test_target_interpolation_and_actual_dwell(self):
        trajectory = RandomTargets(seed=17)
        self.assertEqual(trajectory.values_at(0), (0.0,)*6)
        trajectory.values_at(1.0)
        self.assertEqual(trajectory.phase, 'Moving')
        target = trajectory.target
        self.assertTrue(any(target))
        midpoint = (trajectory.phase_start+trajectory.phase_end)/2
        for actual, expected in zip(trajectory.values_at(midpoint), target):
            self.assertAlmostEqual(actual, expected/2)
        self.assertLessEqual(trajectory.phase_end-trajectory.phase_start, .06)
        arrival = trajectory.phase_end
        self.assertEqual(trajectory.values_at(arrival), target)
        self.assertEqual(trajectory.phase, 'Holding')
        self.assertGreaterEqual(trajectory.phase_end-arrival, 1.4)
        self.assertEqual(trajectory.values_at(arrival+1.0), target)

    def test_random_targets_are_repeatable_bounded_and_not_all_one_axis(self):
        first, second = RandomTargets(seed=123), RandomTargets(seed=123)
        isolated = mixed = False
        distinct = set()
        for tick in range(1500):
            t = tick*0.2
            values = first.values_at(t)
            self.assertEqual(values, second.values_at(t))
            self.assertTrue(all(abs(v) <= 30 for v in values[:3]))
            self.assertTrue(all(abs(v) <= 1.5 for v in values[3:]))
            target = first.target
            distinct.add(target)
            nonzero = sum(v != 0 for v in target[:3])
            isolated |= nonzero == 1
            mixed |= nonzero == 3
        self.assertTrue(isolated and mixed)
        self.assertGreater(len(distinct), 20)

    def test_worker_zero_record_source_and_stop(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'demo.csv'
            engine = DemoEngine(seed=20)
            engine.trajectory.phase_end = 0.0
            engine.start()
            try:
                self.wait_for(lambda: engine.latest is not None and any(engine.latest[1]))
                engine.command('record', path)
                self.wait_for(lambda: engine.recording)
                engine.command('zero')
                self.wait_for(lambda: engine.zero_result == 'Demo zero complete')
                snapshot = engine.snapshot()
                self.assertEqual(len(snapshot), 8)
                self.assertEqual(snapshot[1], 'Demo')
                self.assertEqual(snapshot[0][-1][1], (0.0,)*6)
                self.assertEqual(engine.demo_info(), {'target': (0.0,)*6, 'phase': 'Holding', 'progress': 1.0})
                self.wait_for(lambda: engine.count >= 8)
            finally:
                engine.stop()
                engine.join(timeout=1)
            self.assertFalse(engine.is_alive())
            self.assertFalse(engine.recording)
            self.assertEqual(engine.snapshot()[1], 'Disconnected')
            with path.open(newline='', encoding='utf-8') as stream:
                rows = list(csv.DictReader(stream))
            self.assertTrue(rows)
            self.assertTrue(all(row['profile'] == 'DEMO' for row in rows))
            self.assertTrue(all('Fz_N' in row and 'Tz_Nm' in row for row in rows))

    def test_existing_csv_is_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'existing.csv'
            path.write_text('keep me', encoding='utf-8')
            engine = DemoEngine()
            with self.assertLogs(level='ERROR'):
                engine.command('record', path)
                engine._commands(0)
            self.assertFalse(engine.recording)
            self.assertTrue(engine.zero_result.startswith('CSV error:'))
            self.assertEqual(path.read_text(encoding='utf-8'), 'keep me')


if __name__ == '__main__':
    unittest.main()
